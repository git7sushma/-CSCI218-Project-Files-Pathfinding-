import pygame
import math
from queue import PriorityQueue
import time
import random
import statistics

# -------------------
# Pygame init
# -------------------
pygame.init()

# -------------------
# Config
# -------------------
WIDTH = 600
ROWS = 30
HUD_HEIGHT = 60  # medium choice
GRID_HEIGHT = WIDTH - HUD_HEIGHT
win = pygame.display.set_mode((WIDTH, WIDTH))
pygame.display.set_caption("Pathfinding Demo with Moving Obstacles + HUD")

FONT = pygame.font.SysFont("Arial", 14)
BIG_FONT = pygame.font.SysFont("Arial", 16, bold=True)

# -------------------
# Colors
# -------------------
RED = (255, 0, 0)          # closed set node
GREEN = (0, 255, 0)        # open set node 
BLUE = (64, 224, 208)      # final path
YELLOW = (255, 255, 0)     # start node
PURPLE = (128, 0, 128)     # initial end node (now changed to target img)
BLACK = (0, 0, 0)          # obstacle node
WHITE = (255, 255, 255)    # empty cell
GREY = (128, 128, 128)     # grid lines
AGENT_COLOR = (255, 165, 0) # moving agent
MOV_OBST_COLOR = (200, 80, 0) # this is orange obstacle node 
WEIGHT_COLOR = (200, 200, 200)
HUD_BG = (40, 40, 40)
HUD_TEXT = (230, 230, 230)

# -------------------
# Node class
# -------------------
class Node:
    def __init__(self, r, c, w):
        self.row = r
        self.col = c
        self.x = r * w
        self.y = c * w
        self.width = w
        self.color = WHITE
        self.neighbors = []
        self.weight = 1  # traversal cost (1 = normal)
    def pos(self):
        return (self.row, self.col)
    def reset(self):
        self.color = WHITE
        self.weight = 1
    def make_start(self):
        self.color = YELLOW
    def make_end(self):
        self.color = PURPLE
    def make_obstacle(self):
        self.color = BLACK
    def make_closed(self):
        self.color = RED
    def make_open(self):
        self.color = GREEN
    def make_path(self):
        self.color = BLUE
    def make_weighted(self, cost=5):
        self.weight = cost
        self.color = WEIGHT_COLOR
    def is_obstacle(self):
        return self.color == BLACK
    def is_start(self):
        return self.color == YELLOW
    def is_end(self):
        return self.color == PURPLE
    def draw(self, surface):
        pygame.draw.rect(surface, self.color, (self.x, self.y, self.width, self.width))
        # optionally draw weight number for high weights (small)
        if self.weight != 1 and self.color != BLACK:
            txt = FONT.render(str(self.weight), True, (60, 60, 60))
            surface.blit(txt, (self.x + 2, self.y + 2))

    def update_neighbors(self, grid, moving_obstacles, allow_diagonal=False):
        self.neighbors = []

        def blocked(node):
            if node.is_obstacle():
                return True
            # moving obstacles treat current node as blocked
            for mob in moving_obstacles:
                if mob.current_node() == node:
                    return True
            return False

        directions = [
            (1, 0), (-1, 0), (0, 1), (0, -1)
        ]
        diag_dirs = [(1,1),(1,-1),(-1,1),(-1,-1)]
        if allow_diagonal:
            directions += diag_dirs

        for dr, dc in directions:
            nr, nc = self.row + dr, self.col + dc
            if 0 <= nr < ROWS and 0 <= nc < ROWS:
                neighbor = grid[nr][nc]
                if not blocked(neighbor):
                    # For diagonal movement you might want to prevent cutting corners when obstacles block both adjacent cardinal cells.
                    if (dr, dc) in diag_dirs:
                        # check corner cutting (allow only if at least one adjacent cardinal is free)
                        adj1 = grid[self.row + dr][self.col]  # vertical neighbor
                        adj2 = grid[self.row][self.col + dc]  # horizontal neighbor
                        if adj1.is_obstacle() and adj2.is_obstacle():
                            continue
                        # also consider moving obstacles blocking adjacents
                        blocked_adj = False
                        for mob in moving_obstacles:
                            if mob.current_node() in (adj1, adj2):
                                blocked_adj = True
                                break
                        if blocked_adj:
                            continue
                    self.neighbors.append(neighbor)

# -------------------
# Moving obstacle class
# -------------------
class MovingObstacle:
    def __init__(self, node_list, color=MOV_OBST_COLOR, speed=1):
        """
        node_list: list of Node objects the obstacle will move through
        speed: "frames" to wait between moves - bigger = slower (not precise timing)
        """
        self.nodes = node_list
        self.color = color
        self.index = 0
        self.forward = True
        self.frame_counter = 0
        self.speed = max(1, int(speed))

    def update(self):
        # call each frame; only move every self.speed frames
        self.frame_counter += 1
        if self.frame_counter < self.speed:
            return
        self.frame_counter = 0

        if self.forward:
            self.index += 1
            if self.index >= len(self.nodes) - 1:
                self.index = len(self.nodes) - 1
                self.forward = False
        else:
            self.index -= 1
            if self.index <= 0:
                self.index = 0
                self.forward = True

    def draw(self, surface):
        node = self.current_node()
        pygame.draw.rect(surface, self.color, (node.x, node.y, node.width, node.width))

    def current_node(self):
        return self.nodes[self.index]

# -------------------
# Heuristic for A*
# -------------------
def heuristic(a, b):
    (x1, y1) = a
    (x2, y2) = b
    # Manhattan
    return abs(x1 - x2) + abs(y1 - y2)

# -------------------
# Path reconstruction
# -------------------
def reconstruct_path(came_from, current, draw):
    path_nodes = []
    while current in came_from:
        current = came_from[current]
        current.make_path()
        path_nodes.append(current)
        draw()
    return path_nodes[::-1]

# -------------------
# Dijkstra
# -------------------
def dijkstra(draw, grid, start, end):
    t0 = time.time()
    count = 0
    pq = PriorityQueue()
    pq.put((0, count, start))
    distances = {node: float("inf") for row in grid for node in row}
    distances[start] = 0
    came_from = {}
    visited = set()

    while not pq.empty():
        _, _, current = pq.get()
        if current in visited:
            continue
        visited.add(current)

        if current == end:
            path_nodes = reconstruct_path(came_from, end, draw)
            end.make_end()
            start.make_start()
            return path_nodes, time.time() - t0

        for neighbor in current.neighbors:
            # use weight
            new_dist = distances[current] + neighbor.weight
            if new_dist < distances[neighbor]:
                distances[neighbor] = new_dist
                came_from[neighbor] = current
                pq.put((new_dist, count, neighbor))
                neighbor.make_open()
                count += 1

        draw()
        if current != start:
            current.make_closed()

    return [], time.time() - t0

# -------------------
# A* Algorithm
# -------------------
def a_star(draw, grid, start, end):
    t0 = time.time()
    count = 0
    pq = PriorityQueue()
    pq.put((0, count, start))
    came_from = {}
    g_score = {node: float("inf") for row in grid for node in row}
    g_score[start] = 0
    f_score = {node: float("inf") for row in grid for node in row}
    f_score[start] = heuristic(start.pos(), end.pos())
    open_hash = {start}

    while not pq.empty():
        current = pq.get()[2]
        if current in open_hash:
            open_hash.remove(current)

        if current == end:
            path_nodes = reconstruct_path(came_from, end, draw)
            end.make_end()
            start.make_start()
            return path_nodes, time.time() - t0

        for neighbor in current.neighbors:
            temp_g = g_score[current] + neighbor.weight
            if temp_g < g_score[neighbor]:
                came_from[neighbor] = current
                g_score[neighbor] = temp_g
                f_score[neighbor] = temp_g + heuristic(neighbor.pos(), end.pos())
                if neighbor not in open_hash:
                    count += 1
                    pq.put((f_score[neighbor], count, neighbor))
                    open_hash.add(neighbor)
                    neighbor.make_open()

        draw()
        if current != start:
            current.make_closed()

    return [], time.time() - t0

# -------------------
# Grid setup & drawing
# -------------------
def make_grid():
    grid = []
    gap = WIDTH // ROWS  # Changed from GRID_HEIGHT to WIDTH
    for i in range(ROWS):
        grid.append([])
        for j in range(ROWS):
            grid[i].append(Node(i, j, gap))
    return grid

def draw_grid(surface, grid):
    gap = WIDTH // ROWS  # Changed from GRID_HEIGHT to WIDTH
    for i in range(ROWS + 1):
        # horizontal lines (grid) - only draw up to GRID_HEIGHT vertically
        if i * gap <= GRID_HEIGHT:
            pygame.draw.line(surface, GREY, (0, i * gap), (WIDTH, i * gap))
    for i in range(ROWS + 1):
        # vertical lines - draw full height up to GRID_HEIGHT
        pygame.draw.line(surface, GREY, (i * gap, 0), (i * gap, GRID_HEIGHT))

def draw(surface, grid, moving_obstacles, selected_algo, allow_diagonal, weighted_on):
    # draw grid area
    surface.fill(WHITE)
    
    # Draw cells
    for row in grid:
        for node in row:
            node.draw(surface)

    # draw moving obstacles on grid region
    for mob in moving_obstacles:
        mob.draw(surface)

    # ADDED: Draw grid lines
    draw_grid(surface, grid)

    # draw vertical divider (grid ends at GRID_HEIGHT)
    # draw HUD background
    hud_rect = pygame.Rect(0, GRID_HEIGHT, WIDTH, HUD_HEIGHT)
    pygame.draw.rect(surface, HUD_BG, hud_rect)

    # HUD texts
    help_text_lines = [
        "Left-click: place Start, Goal, Obstacles | Right-click: erase",
        "1: A* | 2: Dijkstra | SPACE: Run chosen algorithm",
        "B: Benchmark random maps | D: Toggle diagonal | W: Toggle weighted terrain",
        "R: Reset grid | Moving obstacles move back & forth and are treated as walls",
    ]
    # draw first line in bold with selected algorithm / toggles
    status = f"Algorithm: {'A*' if selected_algo==1 else 'Dijkstra'}    Diagonal: {'ON' if allow_diagonal else 'OFF'}    Weights: {'ON' if weighted_on else 'OFF'}"
    status_surf = BIG_FONT.render(status, True, HUD_TEXT)
    surface.blit(status_surf, (8, GRID_HEIGHT + 6))

    # draw other lines
    for i, line in enumerate(help_text_lines):
        txt = FONT.render(line, True, HUD_TEXT)
        surface.blit(txt, (8, GRID_HEIGHT + 28 + i * 16))

    pygame.display.update()

def get_clicked_pos(mouse_pos):
    x, y = mouse_pos
    gap = WIDTH // ROWS  # Changed from GRID_HEIGHT to WIDTH
    # keep clicks only inside grid area (above HUD)
    if x < 0 or x >= WIDTH or y < 0 or y >= GRID_HEIGHT:
        return None, None
    # original code used (x//gap, y//gap) mapping - row := x//gap, col := y//gap
    return x // gap, y // gap

# -------------------
# Agent animation
# -------------------
def move_agent(surface, path_nodes):
    if not path_nodes:
        return
    agent_radius = WIDTH // ROWS // 2 - 1  # Changed from GRID_HEIGHT to WIDTH
    for node in path_nodes:
        # redraw node's background (path already colored)
        pygame.draw.circle(surface, AGENT_COLOR, (node.x + node.width // 2, node.y + node.width // 2), agent_radius)
        pygame.display.update()
        pygame.time.delay(80)

# -------------------
# Benchmark function
# -------------------
def run_benchmark(grid_template_func, moving_obstacles_template, runs=30, obstacle_density=0.20, diagonal=False, weighted=False):
    """Run simple benchmark: random obstacles placed, random start/end.
       Prints success rate, avg time, avg path length for both A* and Dijkstra.
    """
    results = {"A*": {"times": [], "lengths": [], "success": 0},
               "Dijkstra": {"times": [], "lengths": [], "success": 0}}
    for r in range(runs):
        grid = grid_template_func()
        # randomly place obstacles
        for row in grid:
            for node in row:
                if random.random() < obstacle_density:
                    node.make_obstacle()
        # optionally assign weighted cells
        if weighted:
            for _ in range(int(ROWS * ROWS * 0.05)):  # 5% weighted cells
                rr = random.randrange(ROWS)
                cc = random.randrange(ROWS)
                if not grid[rr][cc].is_obstacle():
                    grid[rr][cc].make_weighted(cost=random.choice([3,5,8]))

        # pick random start/end on free cells
        free_nodes = [n for row in grid for n in row if not n.is_obstacle()]
        if len(free_nodes) < 2:
            continue
        start = random.choice(free_nodes)
        end = random.choice(free_nodes)
        if start == end:
            continue
        start.make_start()
        end.make_end()

        # update neighbors
        moving_obstacles = moving_obstacles_template(grid)
        for row in grid:
            for node in row:
                node.update_neighbors(grid, moving_obstacles, allow_diagonal=diagonal)

        # A*
        path, t = a_star(lambda: None, grid, start, end)
        if path:
            results["A*"]["success"] += 1
            results["A*"]["lengths"].append(len(path))
        results["A*"]["times"].append(t)

        # Dijkstra
        # for Dijkstra, use distances with same neighbor update
        path2, t2 = dijkstra(lambda: None, grid, start, end)
        if path2:
            results["Dijkstra"]["success"] += 1
            results["Dijkstra"]["lengths"].append(len(path2))
        results["Dijkstra"]["times"].append(t2)

    # print results
    for algo in ("A*", "Dijkstra"):
        times = results[algo]["times"]
        lengths = results[algo]["lengths"]
        success = results[algo]["success"]
        print("=== Benchmark:", algo, "===")
        print(f"Runs: {runs}")
        print(f"Success: {success}/{runs} ({(success/runs*100):.1f}%)")
        print(f"Avg time: {statistics.mean(times):.5f} s (median {statistics.median(times):.5f})")
        if lengths:
            print(f"Avg path length (when found): {statistics.mean(lengths):.2f}")
        else:
            print("Avg path length: N/A (no successful runs)")
        print()

# -------------------
# Main program & initial setup
# -------------------
grid = make_grid()

# create a sample moving obstacle: horizontal on row 15 from col 5 to 20
moving_obstacles = []
path_nodes = [grid[15][i] for i in range(5, 21)]
moving_obstacles.append(MovingObstacle(path_nodes, speed=3))  # speed larger -> slower movement

start = None
end = None

# state toggles
selected_algo = 1  # 1 = A*, 2 = Dijkstra
allow_diagonal = False
weighted_on = False
running = True
clock = pygame.time.Clock()

# helper to build moving obstacles template for benchmark (no dependencies on current objects)
def benchmark_moving_obstacles_template(grid):
    # for benchmark we will create a simple moving obstacle path if grid large enough
    mobs = []
    if ROWS >= 10:
        mid = ROWS // 2
        length = max(4, ROWS // 4)
        start_col = max(1, ROWS // 6)
        nodes = [grid[mid][c] for c in range(start_col, start_col + length)]
        mobs.append(MovingObstacle(nodes, speed=1))
    return mobs

# -------------------
# Main Loop
# -------------------
while running:
    clock.tick(60)  # limit to 60 FPS

    # update moving obstacles
    for mob in moving_obstacles:
        mob.update()

    # update display and HUD
    draw(win, grid, moving_obstacles, selected_algo, allow_diagonal, weighted_on)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # mouse input (LEFT: place, RIGHT: erase)
        if pygame.mouse.get_pressed()[0]:  # left
            pos = pygame.mouse.get_pos()
            row, col = get_clicked_pos(pos)
            if row is None:
                continue
            node = grid[row][col]
            if not start and node != end and not node.is_obstacle():
                start = node
                start.make_start()
            elif not end and node != start and not node.is_obstacle():
                end = node
                end.make_end()
            elif node != start and node != end:
                node.make_obstacle()

        elif pygame.mouse.get_pressed()[2]:  # right
            pos = pygame.mouse.get_pos()
            row, col = get_clicked_pos(pos)
            if row is None:
                continue
            node = grid[row][col]
            node.reset()
            if node == start:
                start = None
            if node == end:
                end = None

        if event.type == pygame.KEYDOWN:
            # Algorithm selection
            if event.key == pygame.K_1:
                selected_algo = 1
            if event.key == pygame.K_2:
                selected_algo = 2

            # Run pathfinding
            if event.key == pygame.K_SPACE and start and end:
                # refresh neighbors given current moving obstacles & toggles
                for r in range(ROWS):
                    for c in range(ROWS):
                        grid[r][c].update_neighbors(grid, moving_obstacles, allow_diagonal=allow_diagonal)

                if selected_algo == 1:  # A*
                    path, elapsed = a_star(lambda: draw(win, grid, moving_obstacles, selected_algo, allow_diagonal, weighted_on), grid, start, end)
                else:  # Dijkstra
                    path, elapsed = dijkstra(lambda: draw(win, grid, moving_obstacles, selected_algo, allow_diagonal, weighted_on), grid, start, end)

                # ensure start/end colors correct
                if end:
                    end.make_end()
                if start:
                    start.make_start()

                # animate agent along found path (prefer path from selected algo)
                if path:
                    move_agent(win, path)

            # Benchmark
            if event.key == pygame.K_b:
                print("Running benchmark (console output)...")
                run_benchmark(make_grid, benchmark_moving_obstacles_template, runs=30, obstacle_density=0.18, diagonal=allow_diagonal, weighted=weighted_on)
                print("Benchmark complete.")

            # Toggle diagonal
            if event.key == pygame.K_d:
                allow_diagonal = not allow_diagonal

            # Toggle weighted terrain
            if event.key == pygame.K_w:
                weighted_on = not weighted_on
                # mark or clear a fraction of weighted cells
                if weighted_on:
                    # assign some random weighted tiles (5% with random costs)
                    for _ in range(int(ROWS * ROWS * 0.05)):
                        rr = random.randrange(ROWS)
                        cc = random.randrange(ROWS)
                        if not grid[rr][cc].is_obstacle() and not grid[rr][cc].is_start() and not grid[rr][cc].is_end():
                            grid[rr][cc].make_weighted(cost=random.choice([3, 5, 8]))
                else:
                    # reset all weights to 1 but keep obstacles, start, end
                    for row in grid:
                        for node in row:
                            if node.color == WEIGHT_COLOR:
                                node.weight = 1
                                node.color = WHITE

            # Reset grid
            if event.key == pygame.K_r:
                start = None
                end = None
                grid = make_grid()
                moving_obstacles = [MovingObstacle(path_nodes, speed=3)] if 'path_nodes' in globals() else []
                # re-create sample obstacle referencing new grid (safe fallback)
                try:
                    path_nodes = [grid[15][i] for i in range(5, 21)]
                    moving_obstacles = [MovingObstacle(path_nodes, speed=3)]
                except Exception:
                    moving_obstacles = []

    # end event loop

pygame.quit()