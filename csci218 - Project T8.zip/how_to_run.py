
"""
================= HOW TO RUN THE PROGRAM =================

1. Install Pygame:
    pip install pygame

2. Open project folder in VS Code:
    File → Open Folder → Select this folder

3. Run the program:
    - Click "Run" in VS Code
    OR
    - Use terminal: python main.py

----------------------- CONTROLS -------------------------
Left Click  = Place Start, End, or Obstacles  
Right Click = Remove cell  
M + Click   = Create moving obstacle  
D           = Run Dijkstra  
A           = Run A*  
SPACE       = Compare both  
C           = Clear grid

==========================================================
"""
