import pygame
import random
import math
import time
from queue import PriorityQueue

# ------------------------------ paraag
# Window Setup
# ------------------------------
WIDTH = 600
ROWS = 25
win = pygame.display.set_mode((WIDTH, WIDTH))
pygame.display.set_caption("CSCI218 - Pathfinding using A* & Dijkstra")

# ------------------------------
# Colors
# ------------------------------
WHITE = (240,240,240)
BLACK = (0,0,0)
RED = (200,50,50)
GREEN = (70,200,70)
BLUE = (80,140,220)
YELLOW = (240,220,80)
PURPLE = (150,80,200)
GREY = (200,200,200)
AGENT = (40,40,40)
ORANGE = (255,140,0)  # For moving obstacle

# ------------------------------
# Moving Obstacle Class
# ------------------------------ paraag
class MovingObstacle:
    def __init__(self, row, col, grid):
        self.row = row
        self.col = col
        self.grid = grid
        self.direction = -1  # -1 = up, 1 = down
        self.speed = 5  # frames per move (higher = slower)
        self.counter = 0
        
    def update(self):
        self.counter += 1
        if self.counter < self.speed:
            return
        self.counter = 0
        
        # Clear current position
        self.grid[self.row][self.col].reset()
        
        # Try to move
        new_col = self.col + self.direction
        
        # Check boundaries and reverse direction if needed
        if new_col < 0:
            self.direction = 1
            new_col = self.col + self.direction
        elif new_col >= ROWS:
            self.direction = -1
            new_col = self.col + self.direction
        
        # Check if target cell is free
        target = self.grid[self.row][new_col]
        if not (target.is_start() or target.is_end() or target.is_obstacle()):
            self.col = new_col
        else:
            # Reverse direction if blocked
            self.direction *= -1
        
        # Place obstacle at new position
        self.grid[self.row][self.col].color = ORANGE
    
    def draw(self):
        self.grid[self.row][self.col].color = ORANGE


CELL = WIDTH // ROWS
g_img = pygame.image.load("t.png")
g_img = pygame.transform.scale(g_img, (CELL, CELL))
# ------------------------------
# Node Class
# ------------------------------ sushma
class Node:
    def __init__(self, row, col, width):
        self.row = row
        self.col = col
        self.x = row * width
        self.y = col * width
        self.width = width
        self.color = WHITE
        self.neighbors = []

    def pos(self):
        return self.row, self.col

    def reset(self):
        self.color = WHITE
    def make_start(self):
        self.color = YELLOW
    def make_end(self):
        self.color = PURPLE
    def make_obstacle(self):
        self.color = BLACK
    def make_open(self):
        self.color = GREEN
    def make_closed(self):
        self.color = RED
    def make_path(self):
        self.color = BLUE

    def is_start(self): return self.color == YELLOW
    def is_end(self): return self.color == PURPLE
    def is_obstacle(self): return self.color == BLACK or self.color == ORANGE
    def is_moving(self): return self.color == ORANGE

    def draw(self, win):
        rect = (self.x, self.y, self.width, self.width)
        if self.color == PURPLE:
            win.blit(g_img, (self.x, self.y))
        else:
            pygame.draw.rect(win, self.color, rect)

    def update_neighbors(self, grid):
        self.neighbors = []
        r, c = self.row, self.col
        if r < ROWS - 1 and not grid[r+1][c].is_obstacle(): self.neighbors.append(grid[r+1][c])
        if r > 0 and not grid[r-1][c].is_obstacle(): self.neighbors.append(grid[r-1][c])
        if c < ROWS - 1 and not grid[r][c+1].is_obstacle(): self.neighbors.append(grid[r][c+1])
        if c > 0 and not grid[r][c-1].is_obstacle(): self.neighbors.append(grid[r][c-1])

# ------------------------------
# Manhattan 
# ------------------------------ sushma 
def heuristic(a, b):
    (x1, y1) = a
    (x2, y2) = b
    return abs(x1 - x2) + abs(y1 - y2)

def reconstruct_path(came_from, current, draw):
    path = []
    while current in came_from:
        current = came_from[current]
        current.make_path()
        path.append(current)
        draw()
    return list(reversed(path))

# ------------------------------
# Dijkstra's Algorithm
# ------------------------------
def dijkstra(draw, grid, start, end):
    print("\nRunning Dijkstra…")
    t0 = time.time()
    pq = PriorityQueue()
    pq.put((0, 0, start))
    distances = {node: float("inf") for row in grid for node in row}
    distances[start] = 0
    came_from = {}
    visited = set()
    count = 0

    while not pq.empty():
        _, _, current = pq.get()
        if current in visited: continue
        visited.add(current)

        if current == end:
            print("Dijkstra finished in", round(time.time() - t0, 4), "seconds.")
            return reconstruct_path(came_from, end, draw)

        for neighbor in current.neighbors:
            new_dist = distances[current] + 1
            if new_dist < distances[neighbor]:
                distances[neighbor] = new_dist
                came_from[neighbor] = current
                count += 1
                pq.put((new_dist, count, neighbor))
                neighbor.make_open()

        draw()
        if current != start: current.make_closed()

    print("Dijkstra: No path found.")
    return []

# ------------------------------
# A* Algorithm
# ------------------------------
def a_star(draw, grid, start, end):
    print("\nRunning A*…")
    t0 = time.time()
    pq = PriorityQueue()
    pq.put((0, 0, start))
    g = {node: float("inf") for row in grid for node in row}
    f = {node: float("inf") for row in grid for node in row}
    g[start] = 0
    f[start] = heuristic(start.pos(), end.pos())
    came_from = {}
    open_set = {start}
    count = 0

    while not pq.empty():
        _, _, current = pq.get()
        open_set.remove(current)
        if current == end:
            print("A* finished in", round(time.time() - t0, 4), "seconds.")
            return reconstruct_path(came_from, end, draw)

        for neighbor in current.neighbors:
            new_g = g[current] + 1
            if new_g < g[neighbor]:
                g[neighbor] = new_g
                f[neighbor] = new_g + heuristic(neighbor.pos(), end.pos())
                came_from[neighbor] = current
                if neighbor not in open_set:
                    count += 1
                    pq.put((f[neighbor], count, neighbor))
                    open_set.add(neighbor)
                    neighbor.make_open()

        draw()
        if current != start: current.make_closed()

    print("A*: No path found.")
    return []

# ------------------------------
# Grid Drawing
# ------------------------------
def make_grid():
    grid = []
    size = WIDTH // ROWS
    for r in range(ROWS):
        grid.append([])
        for c in range(ROWS):
            grid[r].append(Node(r, c, size))
    return grid

def draw_grid(win):
    gap = WIDTH // ROWS
    for i in range(ROWS):
        pygame.draw.line(win, GREY, (0, i*gap), (WIDTH, i*gap))
        pygame.draw.line(win, GREY, (i*gap, 0), (i*gap, WIDTH))

def draw(win, grid):
    win.fill(WHITE)
    for row in grid:
        for node in row:
            node.draw(win)
    draw_grid(win)
    pygame.display.update()

def get_clicked_pos(pos):
    gap = WIDTH // ROWS
    x, y = pos
    return x // gap, y // gap

def move_agent(win, path):
    radius = WIDTH // ROWS // 2 - 1
    for node in path:
        pygame.draw.circle(win, AGENT, (node.x + node.width//2, node.y + node.width//2), radius)
        pygame.display.update()
        pygame.time.delay(120)

# ------------------------------
# Main Loop
# ------------------------------
grid = make_grid()
start = None
end = None
running = True
clock = pygame.time.Clock()

# List to store moving obstacles
moving_obstacles = []
m_mode = False  # Track if M key mode is active

print("\n==============================")
print("Controls:")
print("Left Click  = Place start, end, obstacles")
print("Right Click = Remove")
print("Press M, then click obstacle = Make it move up/down")
print("D = Run Dijkstra")
print("A = Run A*")
print("SPACE = Compare both")
print("C = Clear grid")
print("==============================\n")

while running:
    clock.tick(60)  # 60 FPS
    
    # Update all moving obstacles
    for mob in moving_obstacles:
        mob.update()
    
    draw(win, grid)
    
    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False

        # Mouse inputs
        if pygame.mouse.get_pressed()[0]:  # left click
            x, y = pygame.mouse.get_pos()
            r, c = get_clicked_pos((x, y))
            node = grid[r][c]
            
            # Check if M mode is active
            if m_mode:
                # Make obstacle move
                if node.is_obstacle() and not node.is_moving():
                    node.reset()
                    moving_obstacles.append(MovingObstacle(r, c, grid))
                    print(f"Created moving obstacle at ({r}, {c})")
                    m_mode = False  # Turn off M mode after creating
                    print("M Mode OFF")
            else:
                # Normal placement
                if not start and node != end:
                    start = node
                    start.make_start()
                elif not end and node != start:
                    end = node
                    end.make_end()
                elif node != start and node != end:
                    node.make_obstacle()

        if pygame.mouse.get_pressed()[1]:  # middle click
            pass  # Disabled middle click

        if pygame.mouse.get_pressed()[2]:  # right click
            x, y = pygame.mouse.get_pos()
            r, c = get_clicked_pos((x, y))
            node = grid[r][c]
            
            # Remove moving obstacle if exists at this position
            moving_obstacles[:] = [mob for mob in moving_obstacles if not (mob.row == r and mob.col == c)]
            
            node.reset()
            if node == start: start = None
            if node == end: end = None

        # Keyboard inputs
        if event.type == pygame.KEYDOWN:
            # Toggle M mode
            if event.key == pygame.K_m:
                m_mode = not m_mode
                if m_mode:
                    print("M Mode ON: Click on an obstacle to make it move")
                else:
                    print("M Mode OFF")
            
            if event.key == pygame.K_d and start and end:
                for row in grid:
                    for node in row:
                        node.update_neighbors(grid)
                dijkstra(lambda: draw(win, grid), grid, start, end)

            elif event.key == pygame.K_a and start and end:
                for row in grid:
                    for node in row:
                        node.update_neighbors(grid)
                a_star(lambda: draw(win, grid), grid, start, end)

            elif event.key == pygame.K_SPACE and start and end:
                print("\n--- Comparing: Dijkstra then A* ---")
                # Update neighbors first
                for row in grid:
                    for node in row:
                        node.update_neighbors(grid)

                # Run Dijkstra
                dijkstra_path = dijkstra(lambda: draw(win, grid), grid, start, end)
                if dijkstra_path:
                    move_agent(win, dijkstra_path)

                # Reset grid but keep start/end/obstacles
                for row in grid:
                    for node in row:
                        if not (node.is_start() or node.is_end() or node.is_obstacle()):
                            node.reset()
                for row in grid:
                    for node in row:
                        node.update_neighbors(grid)

                # Run A*
                a_star_path = a_star(lambda: draw(win, grid), grid, start, end)
                if a_star_path:
                    move_agent(win, a_star_path)

            elif event.key == pygame.K_c:
                start = None
                end = None
                moving_obstacles = []
                grid = make_grid()

pygame.quit()