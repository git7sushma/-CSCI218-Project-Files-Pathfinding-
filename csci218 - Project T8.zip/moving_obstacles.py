class MovingObstacle:
    def __init__(self, row, col, grid):
        self.row = row
        self.col = col
        self.grid = grid
        self.direction = -1 # -1 = up, 1 = down
        self.speed = 5 # frames per move (higher = slower)
        self.counter = 0

    def update(self):
        self.counter += 1
        if self.counter < self.speed:
            return
        self.counter = 0

# Clear current position
        self.grid[self.row][self.col].reset()

# Try to move
        new_col = self.col + self.direction

# Check boundaries and reverse direction if needed
        if new_col < 0:
            self.direction = 1
            new_col = self.col + self.direction
        elif new_col >= ROWS:
            self.direction = -1
            new_col = self.col + self.direction

# Check if target cell is free
        target = self.grid[self.row][new_col]
        if not (target.is_start() or target.is_end() or target.is_obstacle()):
            self.col = new_col
        else:
# Reverse direction if blocked
            self.direction *= -1

# Place obstacle at new position
            self.grid[self.row][self.col].color = ORANGE

    def draw(self):
        self.grid[self.row][self.col].color = ORANGE

moving_obstacles = []
m_mode = False

# Inside the main while loop:
while running:
    clock.tick(60)

# Update all moving obstacles
    for mob in moving_obstacles:
        mob.update()